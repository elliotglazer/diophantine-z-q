# Boundary-scalar formula for a common-strict determinant switch

Date: 8 November 2026.

Status: ordinary algebraic derivation supplied by the reviewing assistant; not yet Lean-formalized or independently accepted. It is not an arithmetic Selmer-complex theorem. The accompanying exact checker is finite regression evidence, not its proof.

## 1. Purpose and relation to the committed packet

The six lemmas at `CheyLoveday/diophantine-z-q`, commit
`40d01c53b3545a62949b14669c4906d3e978110e`, identify boundary kernels,
exclude one identity-on-strict triangle square, and transport local area.
They do not compute the class-functional determinant tensor under the
comparison supplied by the separate exact triangles.

The theorem below computes that comparison in an explicit common-strict
two-term presentation. Its conclusion is an exact scalar formula. Its
additional inputs are cross-boundary evaluations of the actual functionals,
not a hypothesis that the target determinant coordinates already agree.

## 2. Assumptions and definitions

Let R be a DVR with fraction field L. Fix n >= 2 and m = n-2.
Use column vectors for classes and row vectors for functionals.

Take integral matrices

    D0 : R^m -> R^n,
    AF : R^2 -> R^n,
    AS : R^2 -> R^n,

and set

    DF = [D0 | AF],      DS = [D0 | AS].

These present complexes CF and CS in cohomological degrees one and two,
with common strict subcomplex K = [R^m -> R^n]. Their degreewise quotient
complexes are F[-1] and S[-1], where F = S = R^2 with independently chosen
bases. These are two short exact sequences of complexes, not a morphism
of triangles fixing K.

Assume:

1. D0 has rank m over L.
2. J is an integral isomorphism F -> S. Write delta = det(J) in R^times.
3. zF = (hF,v) and zS = (hS,Jv) are actual integral cycles of DF and DS,
   with v nonzero. Neither cycle nor v is required to be primitive.
4. lambdaF and lambdaS are nonzero L-valued closed row functionals:
   lambdaF DF = 0 and lambdaS DS = 0. Integral functionals, or functionals
   made integral by the same fixed clearing factor, are special cases.
5. For x in L^2 with eta = det[v,x] nonzero, the matrix

       T = [D0 | a | b],     a = AF x,     b = AS Jx,

   is invertible over L. Write theta = det(T).

The last assumption is generic boundary-image independence, with the strict
image retained. In the manuscript's two-dimensional strict generic H2, its
`AxesKernel` description implies it: any relation between a and b modulo
im(D0) would put a vector with x-component outside Lv into the combined
boundary kernel. Full implementation must construct this quotient and its
identification; the six committed theorems do not do that construction.

Define the cross-boundary scalars

    qF = lambdaF(b),      qS = lambdaS(a).

They are nonzero: lambdaF kills im(D0) and a, which together have dimension
n-1, so a nonzero lambdaF cannot also kill b. The singular case is identical.

Over L both DF and DS have rank n-1. Define their tensor coordinates in the
adjugate convention by

    zF lambdaF = uF adj(DF),
    zS lambdaS = uS adj(DS).

Rank n-1, nonzero cycles, and nonzero closed functionals imply that these
nonzero scalars exist uniquely. This is the same concrete cofactor convention
used by the committed Python normalization test. Sign conventions for other
implementations of the graded determinant functor must be translated; a sign
change never affects the DVR valuation conclusion below.

## 3. Exact theorem

Under these assumptions,

    uF = -eta qF / theta,
    uS = delta eta qS / theta.

The determinant-line comparison obtained from the two common-strict short
exact sequences and J acts on the retained line bases by delta. Consequently,

    Phi_det(tauF) / tauS = delta uF/uS = -qF/qS.                (1)

Here tauF and tauS denote the distinguished class-functional determinant
tensors, not arbitrary generators of their determinant lines.

In particular:

    v_R(uF) - v_R(uS) = v_R(qF) - v_R(qS),                    (2)

because delta is a unit. Thus valuation preservation is equivalent, in this
presentation, to qF/qS being an R-unit.

A common nonzero factor in qF and qS cancels. It is unnecessarily strong to
require each cross-boundary scalar separately to be a unit.

## 4. Proof

Use the domain basis matrix

    BF = [e1,...,em,zF,(0,x)]

for CF. Its determinant is eta, since its lower-right block is [v,x].
For CS use

    BS = [e1,...,em,zS,(0,Jx)],

whose determinant is delta eta. These basis changes are permitted over L;
no integral complement to the possibly divisible vector v is asserted.

Use the common target basis T = [D0,a,b]. The transformed differentials are

    T^-1 DF BF = diag(I_m, NF),      NF = [[0,1],[0,0]],
    T^-1 DS BS = diag(I_m, NS),      NS = [[0,0],[0,1]].

The cycles become the first basis vector in the final two-dimensional block.
Closedness makes the transformed functionals, in that block,

    lambdaF T = (0,qF),       lambdaS T = (qS,0).

The adjugates of the two blocks give coordinates -qF and qS, respectively.

For a general source-basis change B and target-basis change T, write
D' = T^-1 D B, z' = B^-1 z and lambda' = lambda T. The adjugate identity gives

    adj(D') = (det B / det T) B^-1 adj(D) T.

Hence z lambda = u adj(D) transforms to

    z' lambda' = u (det T / det B) adj(D'),

so the old coordinate is the transformed coordinate times det B/det T.
Substituting the two basis determinants proves the displayed uF and uS
formulas. Dividing, including the delta from the determinant-line map,
proves (1); applying the valuation proves (2).

The entire common target determinant theta cancels. In particular, possible
nonunit strict factors in D0 have not been deleted. Their contributions are
present on both sides before the ratio is taken. This is the exact reason
fractional complements and common strict torsion create no additional factor
in the ratio once the cross-boundary normalization is supplied.

This proof does not construct an integral quasi-isomorphism CF -> CS.

## 5. Application contract for the arithmetic comparison

To use (1) for the manuscript, the actual arithmetic construction must supply:

- the common-strict integral presentation, or an explicitly compatible
  determinant-functor replacement for that presentation;
- the same old class A and actual derivative B, not arbitrarily rescaled
  primitive generators;
- the actual closed functionals obtained by conjugation, orthogonal comparison
  and Poitou--Tate duality;
- the cross-boundary adjunctions, in compatible cone and cup-product signs.

A typical sufficient form, for one consistent orientation, is

    lambdaA(iF partialS(s)) = c beta(v,s),
    lambdaB(iS partialF(f)) = -c beta(f,Jv),

with the SAME nonzero c in L, and

    beta(f,s) = epsilon omega(f,Js),
    J^2 = 1,

where omega is alternating and epsilon is the common specified local pairing
factor. These identities are hypotheses here, not conclusions attributed to
the finite Heegner construction.

For s=Jx and f=x, alternation gives

    qF = c epsilon omega(v,x) = qS.

Equation (1) then gives Phi_det(tauF) = -tauS in the declared convention.
Other consistently transported orientation signs replace this by a fixed
unit. More generally, unequal factors cF,cS give a defect governed precisely
by v_R(cF/cS). This is the arithmetic normalization that must actually be
proved; independent existence or integrality of both functionals is not enough.

The theorem makes no uniform-limit assertion. Applying it through an inner
limit, an outer quotient, or the exceptional height-one localizations requires
separate verification of its retained inputs at those exact rings. In
particular, the rank-reducing outer test is not substituted for each rank-one
inner generic instance.

## 6. A stronger negative control

Take R = Z_2 (or Z_(2)), F=S=R^2, K=R^2[-2],

    J = diag(1,-1),  v=e1,
    DF = [[0,2],[0,0]],
    DS = [[0,0],[0,4]],
    zF=zS=e1,
    lambdaF=(0,1), lambdaS=(1,0).

Both classes and both functionals are primitive and integral. The two generic
kernels are Le1. The combined boundary kernel is exactly
L(e1,0) + L(0,e1). The strict complex is literally the same, and the local
quotient lattices modulo the class line are isomorphic. All six committed
abstract lemmas apply.

Nevertheless,

    uF=-1/2,   uS=1/4,   Phi_det(tauF)/tauS=2.

Thus the valuations do not agree. The common strict complex has NO torsion
in this example; the differing torsion comes from the two distinct boundary
images. With x=e2,

    qF=-4,    qS=2,

so formula (1) detects exactly the missing factor. This example does not
satisfy the required common boundary--cup normalization and is NOT a
counterexample to the arithmetic manuscript. It refutes the weaker inference
from axes, local J, integrality and even primitivity alone.

## 7. Finite checks performed

`check_boundary_scalar.py` uses exact standard-library rational arithmetic.
It verifies every entry of z lambda = u adj(D), not just one selected cofactor.

The frozen run has 300 common-strict examples in sizes 2 through 5, with
independent unimodular target and finite/singular basis changes, strict-to-local
source shears, arbitrary powers of two in the common strict differential,
independent finite/singular boundary scales and divisible actual local vectors.

- 152 cases enforce qF=qS and recover ratio -1.
- 129 unequal-scale negative controls recover a nonunit ratio.
- 255 cases have a divisible local vector.
- All 300 satisfy the exact formulas, including the independent primitive
  2-by-2 negative example above.

Normal and optimized Python runs produce byte-identical results. These are
finite regression checks of the ordinary proof, not Lean compilation,
arithmetic realization, or a claim of new literature priority.
