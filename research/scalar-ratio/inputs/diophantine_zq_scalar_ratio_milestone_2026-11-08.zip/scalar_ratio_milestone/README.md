# Common-strict scalar-ratio milestone

Date: 8 November 2026.
Source baseline: `CheyLoveday/diophantine-z-q` at
`40d01c53b3545a62949b14669c4906d3e978110e`.

## Status

- Ordinary matrix derivation: supplied explicitly in `MATHEMATICS.md`.
- Four Lean modules with complete candidate proof bodies: supplied.
- Lean compilation and transitive axiom audit: **NOT_RUN**. No Lean/Lake binary
  is available in the preparation environment; a download attempt was blocked.
  Elaboration or library-interface repairs may still be needed. Do not call
  these kernel-verified theorems, or promote this packet's formal status, until
  the stated build succeeds and its theorem types have been reviewed.
- Exact Python tests: **PASS**, both normally and with `-O`; outputs match.
- Actual arithmetic boundary--cup realization: **not established here**.
- Independent review/acceptance: **not obtained**; this is the same assistant's
  continuation of its previous derivation, not an independent review.
- No GitHub branch, commit, PR, manuscript, acceptance record or visibility
  setting was changed by this work.

## What changed mathematically

The development does not define the answer to be the desired scalar formula.
`HasCoordinate D z lam u` is the full matrix equation

    tensor(z,lam) = u * adjugate(D).

The raw matrix, actual cycle, and closed-functional hypotheses yield

    uF = -eta*qF/theta,
    uS = delta*eta*qS/theta,
    delta*uF/uS = -qF/qS,

with the last quotient used only when its denominator is nonzero.
The common-strict presentation and its normal frames are constructed explicitly.
A nonzero adjugate and uniqueness of the coordinate are separate candidate lemmas.

The integral criterion exhibits units of the actual integral subring R, NOT
merely units of the fraction field. It handles the zero/zero functional case
without division. A separately typed full boundary--cup contract yields the
cross scalars from the actual recorded rows. Common normalization gives
`delta*uF = -uS`; for `det J = -1`, this means `uF = uS` in the fixed cofactor
convention. No proof that arithmetic cochains satisfy the contract is supplied.

## Files to inspect first

1. `MATHEMATICS.md`: complete mathematical implication and proof.
2. `lean/Research/DerivativeSwitch/CommonStrict.lean`: raw source data and formula.
3. `lean/Research/DerivativeSwitch/UnitCriterion.lean`: integral units and zero cases.
4. `lean/Research/DerivativeSwitch/BoundaryCup.lean`: the explicit arithmetic-facing adapter.
5. `ARITHMETIC_CONTRACT.md`: exactly what the manuscript must instantiate.
6. `HANDOFF.md`: integration instructions and acceptance ceiling.

`Coordinate.lean` contains the supporting frame and adjugate calculations.
`PRIOR_DERIVATION.md` is the unchanged earlier ordinary proof, retained as history.

## Reproduce the executed tests

```sh
python3 -B tests/check_milestone.py
python3 -O tests/check_milestone.py
```

Observed: 180 new raw matrix/adapter cases in sizes 2 through 6, 720 full-basis
boundary--cup checks, 540 integral-unit criterion checks at primes 2, 3 and 5,
180 complement changes, 121 common denominator clearings, 90 zero-functional
cases, and 90 wrong-functional negative controls. The earlier 300-case matrix
regression also passes. Utilities from that earlier checker are reused; this
is not an independently implemented checker or an independent review.

## Compile and inspect the formal candidates

Preferred: reuse the existing fork's exact dependency checkouts/caches read-only.
From this bundle's root, with pinned Lean 4.35.0 on PATH:

```sh
python3 -B verify_lean.py \
  --dependencies /path/to/diophantine-z-q/lean/.lake/packages \
  --output /path/to/new/scalar-ratio-check
```

The output directory must be new. The script verifies all nine dependency
revisions, compiles the four new modules in dependency order to fresh output,
and prints/checks 18 target theorem types and their transitive axioms. It
writes `LEAN_RESULT.json` only after success. It does not modify the inherited
48-module snapshot or claim independent checking of dependency caches.

The standalone `lean/lakefile.toml` pins the same Mathlib commit. Its purpose is
an isolated build, not an edit to the fork's frozen Lake configuration. Obtaining
its dependencies should preserve and compare the recorded pins before a build.
A simple `lake build Research` is a preliminary build, not a replacement for
the fresh target/axiom audit above or for semantic source-to-statement review.

Do not alter source statements, add assumptions equivalent to the desired
coordinate equality, introduce proof holes, or update old approval hashes to
make a build pass. Record any repairs and review the changed statements.

## Scope

This packet proves an ordinary algebraic implication and proposes its Lean
formalization. It does not implement a determinant functor, derived Selmer
complexes, Poitou--Tate duality, Galois cochains, or limiting procedures. The
cofactor-to-inverse-determinant identification is an ordinary basis calculation,
not a separately formalized determinant-functor theorem. The main arithmetic
application must retain its actual integral bases and classes.
