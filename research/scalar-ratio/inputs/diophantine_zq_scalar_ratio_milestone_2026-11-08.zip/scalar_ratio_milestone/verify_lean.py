#!/usr/bin/env python3
"""Fresh native compilation and axiom audit of the scalar-ratio candidates.

Requires the pinned Lean compiler and already obtained pinned dependency
caches. Does not edit a repository, fetch dependencies, or produce an
acceptance record. No success receipt is written unless every step succeeds.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'lean'
MODULES = ['Coordinate', 'CommonStrict', 'UnitCriterion', 'BoundaryCup']
PREFIX = 'Research.DerivativeSwitch.ScalarRatio.'
TARGETS = [PREFIX + s for s in (
    'coordinate_of_frame', 'coordinate_of_closed_frame',
    'adjugate_ne_zero_of_frame', 'coordinate_unique',
    'raw_side_coordinate', 'common_strict_coordinate_formula',
    'CommonStrictData.coordinate_values', 'transported_ratio',
    'transported_unit_criterion', 'integral_unit_criterion',
    'CommonStrictData.actual_coordinate_ratio',
    'CommonStrictData.actual_integral_unit_criterion',
    'boundary_cup_cross_evaluations', 'normalization_defect',
    'common_normalization_adapter', 'det_neg_one_common_normalization',
    'integral_boundary_cup_adapter', 'valuation_equal_of_unitRelated')]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dependencies', type=Path, required=True,
                   help='Pinned .lake/packages directory from the fork checkout or this project')
    p.add_argument('--output', type=Path, required=True, help='A new output directory')
    p.add_argument('--lean', default='lean')
    args = p.parse_args()
    output, dependencies = args.output.resolve(), args.dependencies.resolve()
    if output.exists():
        raise RuntimeError('Output must not already exist')
    output.mkdir(parents=True)
    (output/'lib/Research/DerivativeSwitch').mkdir(parents=True)
    pin = json.loads((ROOT/'PINS.json').read_text())
    commands = []

    def run(label, argv, cwd=PROJECT, env=None):
        r = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True)
        (output/(label+'.log')).write_text(r.stdout+r.stderr)
        commands.append({'label':label, 'argv':argv, 'exit_code':r.returncode})
        (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if r.returncode:
            raise RuntimeError(f'{label} failed; inspect the log. No formal PASS is issued.')
        return r.stdout

    version = run('lean-version', [args.lean, '--version']).strip()
    if 'version '+pin['lean_version']+',' not in version or pin['lean_commit'][:7] not in version:
        raise RuntimeError('Wrong compiler version or revision; do not silently upgrade')
    libraries, checked = [], []
    for name, expected in pin['dependencies'].items():
        package = dependencies/name
        actual = run('pin-'+name, ['git', '-C', str(package), 'rev-parse', 'HEAD']).strip()
        if actual != expected:
            raise RuntimeError(f'Dependency pin mismatch: {name}')
        run('clean-'+name, ['git', '-C', str(package), 'diff', '--quiet', 'HEAD', '--'])
        lib = package/'.lake/build/lib/lean'
        if lib.is_dir(): libraries.append(lib)
        checked.append({'name':name,'revision':actual})
    env = os.environ.copy()
    env.pop('LEAN_SRC_PATH', None)
    env['LEAN_PATH'] = os.pathsep.join(map(str, [output/'lib', *libraries]))
    base = [args.lean, '-j1', '-Ddebug.skipKernelTC=false']
    inputs = {}
    for name in MODULES:
        src = Path('Research/DerivativeSwitch')/(name+'.lean')
        inputs[str(src)] = sha(PROJECT/src)
        run(name, base+['-o',str(output/'lib'/src.with_suffix('.olean')),str(src)], env=env)
    auditor = output/'Axioms.lean'
    auditor.write_text('\n'.join([
        'import Research.DerivativeSwitch.BoundaryCup',
        'import Lean.Util.CollectAxioms',
        '#print '+PREFIX+'HasCoordinate',
        '#print '+PREFIX+'CommonStrictData',
        '#print '+PREFIX+'UnitRelated',
        '#print '+PREFIX+'BoundaryCupIdentity',
        'open Lean Elab Command in',
        'run_cmd do',
        '  let names : Array Name := #['+', '.join('`'+t for t in TARGETS)+']',
        '  for name in names do',
        '    let ci ← getConstInfo name',
        '    logInfo m!"STATEMENT {name}: {ci.type}"',
        '    let axs ← collectAxioms name',
        '    for ax in axs do',
        '      unless ax == ``propext || ax == ``Quot.sound || ax == ``Classical.choice do',
        '        throwError "Unexpected axiom {ax} in {name}"',
        '    logInfo m!"AXIOM_CHECK {name}: {axs.toList}"',
        f'  logInfo "SCALAR_RATIO_AUDIT_PASS declarations={len(TARGETS)}"','']))
    log = run('axioms-and-types', base+[str(auditor)],env=env)
    if f'SCALAR_RATIO_AUDIT_PASS declarations={len(TARGETS)}' not in log:
        raise RuntimeError('Axiom audit did not finish')
    actual_targets = re.findall(r'AXIOM_CHECK ([\w.]+):', log)
    if set(actual_targets) != set(TARGETS):
        raise RuntimeError('Audited target set mismatch')
    receipt = {
        'status':'NATIVE_BUILD_AND_AXIOM_AUDIT_PASS',
        'compiler':version, 'dependencies':checked, 'target_names':TARGETS,
        'source_sha256':inputs,
        'dependency_cache':'trusted pinned prebuilt imports; not independently rebuilt',
        'external_checker':'NOT_RUN', 'protected_statement_comparator':'NOT_RUN',
        'arithmetic_realization':'NOT_ESTABLISHED',
        'independent_acceptance':False, 'main_theorem_proved':False}
    (output/'LEAN_RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'targets':len(TARGETS)},indent=2))


if __name__ == '__main__':
    main()
