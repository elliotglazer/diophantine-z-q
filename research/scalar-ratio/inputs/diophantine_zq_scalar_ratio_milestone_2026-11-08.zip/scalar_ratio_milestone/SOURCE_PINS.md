# Source pins and consulted interfaces

- Owner repository: `CheyLoveday/diophantine-z-q`.
- Baseline: `40d01c53b3545a62949b14669c4906d3e978110e`.
- Dependency lock inspected through the connected GitHub source:
  `lean/lake-manifest.json` at that baseline.
- Lean target: `leanprover/lean4:v4.35.0`, compiler revision
  `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`.
- Mathlib: `56a005855ea17e0b0958f73ec801ae140b0a1679`.
- Complete recorded dependency revisions: `PINS.json`.

Pinned Mathlib source interfaces inspected during preparation:

1. `Mathlib/LinearAlgebra/Matrix/Adjugate.lean`:
   `adjugate_mul_distrib`, `adjugate_diagonal`, `mul_adjugate`,
   `adjugate_mul`, and the concrete cofactor convention.
2. `Mathlib/LinearAlgebra/Matrix/NonsingularInverse.lean`:
   `isUnit_iff_isUnit_det`, `isUnits_det_units`, inverse conventions.
3. `Mathlib/LinearAlgebra/Matrix/Determinant/Basic.lean`:
   `det_mul`, `det_fromBlocks_zero₂₁`, `det_permute'`, `det_fin_two`.
4. `Mathlib/Data/Matrix/Block.lean`: `fromBlocks` and index conventions.

Inspecting these sources does NOT constitute compilation of the candidate.
The ordinary proof does not depend on new numerical or unproved arithmetic
claims. All finite tests are exact rational computations.

The previous `BOUNDARY_SCALAR_LEMMA.md` is preserved as `PRIOR_DERIVATION.md`.
Its test helper implementation is reused in `tests/exact_matrix.py`; new tests
are added in `tests/check_milestone.py`. The current preparation is not an
independent review of the earlier derivation.
