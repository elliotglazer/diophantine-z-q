# Proposed fork-only PR packet: derivative-switch connecting lemmas

Target: `CheyLoveday/diophantine-z-q` at upstream-synced `main`, pinned
baseline `9c0b3aba60d90fdcac82115f0582a6f52f1054f7`.

Copy the `lean/Research` and `research/determinant-switch` paths into an
isolated fork review branch. Do not modify the frozen Lean source snapshot,
original manuscript, current acceptance contracts or existing audit history.

**Validation in this environment:**
`python -B research/determinant-switch/check_local_model.py` passed.
**Not validated here:** the Lean 4.35.0 compilation; no Lean toolchain is
installed, so run `cd lean && lake env lean Research/DerivativeSwitchBoundary.lean`
in a properly provisioned checkout. The Lean code is a candidate for an
independent checker, not an accepted formal proof.

The contractual source-to-arithmetic gap is documented in
`research/determinant-switch/CONTRACT.md`. This packet establishes only
finite-dimensional interfaces; it does not settle the main theorem.
