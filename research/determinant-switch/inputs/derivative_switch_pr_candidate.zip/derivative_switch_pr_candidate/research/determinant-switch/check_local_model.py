#!/usr/bin/env python3
"""Exact negative controls for the derivative-switch abstract interface.

Python stdlib only. This tests concrete algebra; it is not a Selmer-complex
proof or a substitute for compiling the accompanying Lean module.
"""
from fractions import Fraction
from math import gcd
from random import Random


def mul(a, v):
    x, y = v
    return (a[0][0] * x + a[0][1] * y,
            a[1][0] * x + a[1][1] * y)


def det(a):
    return a[0][0] * a[1][1] - a[0][1] * a[1][0]


def area(v, w):
    return v[0] * w[1] - v[1] * w[0]


def assert_generic_countermodel(a=3):
    # F, S, H are 2-dimensional over Q. J=diag(1,-1).
    j = ((1, 0), (0, -1))
    d_f = ((0, a), (0, 0))
    d_s = ((0, 0), (0, a))
    assert det(j) == -1
    assert mul(d_f, (1, 0)) == mul(d_s, (1, 0)) == (0, 0)
    # Both generic kernels = Q*(1,0); combined boundary rank 2.
    assert det(((a, 0), (0, a))) == a * a
    # An identity-on-strict/J-on-quotient square is impossible.
    assert mul(d_f, (0, 1)) != mul(d_s, mul(j, (0, 1)))
    # Nevertheless H^1(old) and H^1(new) each have dimension 1.
    return True


def random_unimodular(rng):
    # Compose integral elementary row operations on the identity.
    a = [[1, 0], [0, 1]]
    for _ in range(20):
        i, j = rng.choice(((0, 1), (1, 0)))
        q = rng.randrange(-5, 6)
        a[i][0] += q * a[j][0]
        a[i][1] += q * a[j][1]
        if rng.randrange(5) == 0:
            a[i], a[j] = a[j], a[i]
    if det(a) == 1:
        a[0][0] *= -1
        a[0][1] *= -1
    assert det(a) == -1
    return a


def local_volume_trials():
    rng = Random(20261108)
    count = 0
    for exponent in range(19):
        scale = 2 ** exponent
        # v0=(2,3) is primitive; x0=(-1,-1) gives area(v0,x0)=1.
        v = (2 * scale, 3 * scale)
        x = (Fraction(-1, scale), Fraction(-1, scale))
        assert area(v, x) == 1
        for _ in range(200):
            j = random_unimodular(rng)
            jv, jx = mul(j, v), mul(j, x)
            assert area(jv, jx) == -1
            assert gcd(abs(jv[0]), abs(jv[1])) == scale
            count += 1
    return count


def tensor_normalization_control():
    # Same strict two-dimensional factor, generic class scale 2^k,
    # torsion differential factor 2^m. Two coordinates agree up to sign.
    for m in range(1, 12):
        a = 2 ** m
        for k in range(0, 12):
            u_f = Fraction(2 ** (2 * k), a)
            u_s = -u_f
            assert u_s / u_f == -1
            # Local J + the exact triangles do not force the normalization
            # of the *actual* duality-defined functional.
            wrong_s = 2 * u_s
            assert wrong_s / u_f == -2  # not a 2-adic unit
    return 132


if __name__ == '__main__':
    assert assert_generic_countermodel()
    n = local_volume_trials()
    m = tensor_normalization_control()
    print(f'PASS: generic equal-rank no-go; {n} exact local-volume trials; '
          f'{m} normalization controls')
