# Diophantine Z in Q — consolidated mathematics review packet

Pinned source commit: `40d01c53b3545a62949b14669c4906d3e978110e`

This archive includes: all files under `review/`, including the derivation, boundary-scalar theorem, exact verifier and controls, reviewed Lean/Python modules, and the earlier candidate files; plus the original candidate and review ZIPs and the repository-agent handover under `original_archives_and_handover/`.

## Main reading order

1. `review/REVIEW_40d01c5.md`
2. `review/BOUNDARY_SCALAR_LEMMA.md`
3. `review/check_boundary_scalar.py` and `review/boundary_scalar_results.json`
4. `review/reviewed/DerivativeSwitchBoundary.lean`
5. `review/candidate/derivative_switch_pr_candidate/research/determinant-switch/CONTRACT.md`

## Verification

From extracted bundle root:

```bash
python -B review/check_boundary_scalar.py
python -B review/reviewed/check_local_model.py
```

The finite tests cover abstract determinant and boundary algebra only. The actual arithmetic Selmer-complex functional compatibility and main theorem remain unverified. This is a read-only compilation of available files, not a pushed GitHub change. `FILE_MANIFEST.json` records the checksums of all included source files.
