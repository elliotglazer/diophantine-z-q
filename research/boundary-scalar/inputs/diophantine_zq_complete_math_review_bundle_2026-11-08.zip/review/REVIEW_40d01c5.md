# Contribution-oriented review of derivative-switch work at 40d01c5

Date: 8 November 2026.
Exact commit: `40d01c53b3545a62949b14669c4906d3e978110e`.
Baseline: `9c0b3aba60d90fdcac82115f0582a6f52f1054f7`.
Repository: `CheyLoveday/diophantine-z-q`.

## Verdict

The six-lemma packet is mathematically correct within its explicit abstract
scope and suitable as a bounded formal-coverage contribution in the fork.
It is not yet a proof of determinant-coordinate compatibility, and it should
not be presented as a correction of a global triangle assertion in the
manuscript. That overly strong triangle was introduced in our exploratory
review, not in the printed two-triangle proof.

The useful next mathematical contribution is an exact boundary-scalar formula
for the distinguished determinant tensors, with a source-facing application
contract. A complete ordinary proof and an additional negative control are
supplied in `BOUNDARY_SCALAR_LEMMA.md`. That theorem is not in the reviewed
commit and is not yet Lean-formalized or independently accepted.

This reviewer helped originate the earlier candidate. This is a fresh
adversarial re-review of the committed implementation and mathematics, not a
new non-author acceptance of the original proposed lemmas.

## Scope actually inspected

Fetched through the GitHub connector at the exact commit:

- `lean/Research/DerivativeSwitchBoundary.lean`;
- `research/determinant-switch/CONTRACT.md`;
- `research/determinant-switch/check_local_model.py`;
- `research/determinant-switch/verify.py`;
- `research/determinant-switch/VERIFICATION.md`;
- `research/determinant-switch/PR.md`;
- frozen `RESULT.json` and the final non-author model-review report;
- `verification/compare_exports.lean`;
- `OPENMATH.md`.

The branch comparison showed five commits after the unchanged Version 13 base.
A later observed branch head, `083344e84a231d9127d57589ae5c0b355384579b`, has two
additional commits changing only `OPENMATH.md`; the review remains pinned to
40d01c5 and does not attest that later execution instructions were run.

The inherited printed switch proof was re-read from the retained Version 12
source at the baseline. This is not a new byte-for-byte or full-dependency
audit of the Version 13 manuscript. The branch's own contract identifies the
Version 13 source locations and explicitly leaves arithmetic integration open.

## Observed reproduction and limitations

The exact reviewed Lean source was reconstructed locally and matched both its
Git blob and the frozen SHA-256:

    Git blob: 3d937f5baf5ea47556dbafc865014a379062d6c3
    SHA-256:  63a9215fa55568069d2d1a7b2c3a7345ec21c7ad6a82203f42c5451ee4b8bbea

The exact committed Python checker was independently reconstructed from the
fetched source and matched:

    Git blob: a4bd4c58ee5c212d6dd0fc959c92dbfb13a5c8fc
    SHA-256:  2bdf4fa6ead8c8e656f9b49d9d745a7274f7d3daf81915eb88727271d8988ef1

Its normal run reproduced 3,800 local-volume trials and 132 normalization
controls. Its optimized run correctly rejected execution instead of silently
removing assertions. The new boundary-scalar checker ran in both modes and
produced byte-identical JSON.

No Lean or Lake executable was available in this environment. Consequently
native Lean compilation, axiom audit and protected external-kernel checks were
not rerun here. The existing pinned macOS receipts were inspected as supplied
evidence. A direct container Git clone failed because that runtime could not
resolve github.com; the review used read-only connector retrieval instead.
No full repository or manifest replay is claimed.

## Mathematical findings

### M1. The six theorem statements and elementary proofs are sound

The first two conclusions follow by setting one coordinate of `AxesKernel`
to zero. For the image-intersection result, apply it to `(x,-y)`. For the
fixed-strict no-go result, apply it to `(x,-Jx)` at the supplied vector outside
Kv. The final two results are determinant multiplicativity in dimension two
and its determinant-minus-one specialization.

The code's generality is legitimate. It does not infer characteristic zero,
finite dimensions, or a nonzero v from its assumptions. The corrected contract
explicitly supplies these extra source facts when interpreting generic rank
one. No hidden theorem strengthening was found.

### M2. These are consequences of a strong hypothesis, not its proof

For modules over a field, the `AxesKernel` hypothesis is equivalent to the
conjunction of the two stated kernel-line identities and disjoint boundary
images. The reverse implication follows because dF(x)=-dS(y) is then a common
image and hence zero. Thus the first three formal results extract the contents
of a packaged exact-kernel hypothesis; they do not establish the Selmer
self-annihilator statement that produces it.

The no-go lemma is useful for rejecting our earlier inappropriate comparison
square. The paper's printed switch proof already invokes two separate exact
triangles and a common strict determinant factor. Do not call the no-go lemma
an identified counterexample to a step the paper actually writes.

### M3. The formal package contains no determinant-tensor theorem

There is no formal definition of a Selmer complex, a distinguished triangle,
a determinant line, a class-functional tensor, a DVR valuation, or the actual
Poitou--Tate functional in this module. There is also no formal construction
of the quotient-lattice isomorphism or its Fitting-ideal consequence.
The contract states these boundaries correctly. Therefore a successful
paranoid run of the exact same six targets cannot expand this coverage.

### M4. Integrality and primitivity still do not force the required unit

The new 2-by-2 negative control in `BOUNDARY_SCALAR_LEMMA.md` has a common
strict complex, exact axis kernel, det J=-1, primitive integral cycles,
primitive integral closed functionals and matching local class lines.
Its coordinates are -1/2 and 1/4, and its determinant comparison has ratio 2.
This strengthens the existing control that deliberately rescales a functional:
it shows that unequal boundary-image indices can cause a defect even before
such a rescaling.

This does not refute the arithmetic switch, whose duality compatibility is
not supplied in the countermodel. It identifies exactly which information
must be added before the local algebra becomes a proof of unit transport.

### M5. A concrete stronger theorem is available

In a common-strict two-term presentation, let qF and qS be the evaluations
of the actual old and new closed functionals on the opposite boundary
complements. The exact adjugate/determinant calculation gives

    Phi_det(tauF)/tauS = -qF/qS.

The difference of determinant valuations is exactly the difference of these
two scalar valuations. Common strict torsion and local-vector divisibility
cancel from the ratio, with no primitive-generator substitution.

This is a reusable connecting lemma. It is stronger than local-volume
transport and does not assume equality of the target determinant tensors.
Its arithmetic application still requires identifying qF and qS using the
actual boundary--cup adjunction and retained cochains. The attached note gives
all hypotheses, a complete basis-change proof, sign convention, negative
control, and scope at the limiting rings.

## Formal verification assessment

The native driver compiles the new module explicitly into a fresh target
location, checks the named six declarations' transitive axioms, and keeps the
frozen 48-module snapshot separate. The reported receipts are specifically
bound to the Lean source and contract hashes. The local export probe accurately
labels itself as structural/axiom comparison, not protected kernel replay.
No material false assurance claim was found within those stated scopes.

The six challenge theorems are already solved in the source. A later Open Math
run is additional verification of that solution, not research on an unresolved
mathematical implication. It can finish the promised assurance step, but cannot
replace a new determinant-scalar target or an arithmetic instantiation.

## Contribution decision

Current fork PR: worthwhile as a small, explicitly scoped formal-coverage PR.
Standalone novel mathematical claim: not justified by these six lemmas alone.
Repair of the manuscript's determinant-switch proof: not established.

The next mathematics-bearing increment should contain:

1. a concrete common-strict matrix/determinant interface;
2. the exact boundary-scalar comparison theorem, retaining actual vectors;
3. a source adapter stating the lower-level boundary--cup identities required
   for a unit ratio, with the actual arithmetic instantiation explicitly open.

The third item must not be replaced by an assumption that the desired tensors
are already unit-proportional. Proving a conditional implication from specific
boundary--cup identities is useful even before the full arithmetic adapter is
constructed.

No need to modify the frozen accepted Lean snapshot or the manuscript merely
to house these results. The research namespace can retain the no-go lemmas as
supporting coverage while putting the exact scalar theorem at the centre of
the next scoped contribution.

## Publication and privacy observation

The user supplied a no-push status. At inspection, GitHub served 40d01c5 from
the configured repository and reported `private:false`; the named research
branch was present remotely. The live state therefore differs from that
message. This review performed no push, publication, permission change or
repository write. Historical no-push statements should be treated as dated
records, not the current remote status.

## Primary sources

Repository files above are identified by their exact commit and paths.
For general determinant and triangle conventions:

- Stacks Project, Tag 0FJI, Determinants of complexes.
- Stacks Project, Tag 05QN, Elementary results on triangulated categories.

The ordinary theorem in the accompanying note is derived explicitly rather
than attributed as a new result of those sources. No literature-priority
search or theorem-of-the-full-manuscript claim is made.
