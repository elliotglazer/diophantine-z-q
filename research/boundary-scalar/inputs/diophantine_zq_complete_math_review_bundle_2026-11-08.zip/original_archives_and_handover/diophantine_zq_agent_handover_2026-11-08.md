# Repository-agent handover: independent proof coverage and improvement

**Date:** 8 November 2026  
**Project:** *Z is Diophantine in Q*  
**Primary upstream:** https://github.com/elliotglazer/diophantine-z-q  
**Existing Chey fork:** https://github.com/CheyLoveday/diophantine-z-q  
**Observed upstream head (11:22 UTC):** `9c0b3aba60d90fdcac82115f0582a6f52f1054f7`  
**Observed fork head:** `036cebe4f1a4aa7ca89820a9b48f3629b4c364d6`

## Mission

Clone the **latest actual upstream `main`**, independently review the current proof and its prior audits, then identify and complete **one bounded, high-value contribution**: a verified proof interface, a precise source/application gap or counterexample, an explicit repair, a reusable exact verification, or a defensible quantitative improvement. Prioritize correctness and genuine coverage over novelty, easy variable-count reductions, or repeated AI approval.

Do **not** assume that the observed commits above will still be current. Read the live repository before deciding. Do not treat the main theorem as established merely because its finite algebra or review records pass checks.

## 1. Safe intake and source freeze

Work in a **new, separate clone**. Preserve the existing Chey fork and any local checkouts. On the user's Mac:

```bash
mkdir -p "$HOME/Coding_Projects/diophantine-z-q-independent-review"
cd "$HOME/Coding_Projects/diophantine-z-q-independent-review"
git clone https://github.com/elliotglazer/diophantine-z-q.git upstream
cd upstream
git fetch origin --tags --prune
git switch -c audit/2026-11-08-proof-interface origin/main
git rev-parse HEAD
git status --short --branch
shasum -a 256 manuscripts/quartic_v13.tex  # adjust filename to live README
```

If the target clone or branch exists, **inspect and reuse or select a noncolliding path**; never overwrite, reset or clean an existing checkout. Record the actual `HEAD`, date, main manuscript filename/hash, `git remote -v`, and clean/dirty status. Read the main README before choosing a version. The currently observed upstream README advertises Version 13 (394 symbolic-coefficient variables, 411 all-decimal variables); the fork's main is still Version 10. Treat this as dated context, not a pinned future truth.

Keep research outputs in a **sibling sidecar** directory `../audit-output/`; use the audit branch only if a proposed source patch becomes warranted. No changes to upstream or fork history.

## 2. Mandatory reading and prior-work reconciliation

Read these **in order**, using the latest corresponding paths:

1. `README.md`, `AGENTS.md`, `CONTRIBUTING.md`.
2. `docs/research-review/PROTOCOL.md` (observed v1.2) and `docs/audit-history/PROTOCOL.md`.
3. `docs/audit-history/current.json`, Version 11's Kato repair (`docs/manuscript-revisions/version11/README.md`), and the current version's application/review guide.
4. Main TeX: the restricted-converse construction, finite Heegner descent, integral duality, both limits, six-contact height input, and final consumer.
5. Existing issues #2 and #3, their follow-up comments, and earlier relevant review packets. Read **actual proof arguments**, not only PASS summaries.
6. `lean/README.md` and the relevant finite checkers to determine their exact assurance boundaries.

Prior exploratory audit observations (to reproduce or reject, **not** inherit as verified): Version 10 omitted the Kato 1999 index-set/limiting-class link; Version 11 repaired that interface and Version 13 retained it. The source contains H4 and H12–H22 (Heegner/Kummer class construction), the derivative-switch lemma, class-functional determinant comparisons, uniform bound (5.5), and a Boolean missing-address argument. Earlier spot checks of finite identities were positive, but **no independent end-to-end restricted-converse verification** was obtained. A homotopy-commutative inclusion square is not literally strictly commuting; the printed homotopies or a corrected cone map may resolve this. Do not report that distinction as a proven gap without checking the complete source diagram and Nekovář's functoriality hypotheses.

## 3. Triage: select one contribution

Create a short ranked **coverage matrix**. For each candidate record: exact source statement and consuming passage; previous audits; what remains unverified or improvable; a falsifiable test; likely mathematical impact; estimated difficulty; and whether a duplicate effort is already underway.

**Preferred A — finite Heegner/Kummer → integral determinant comparison.** Inspect H4, H8–H22 and the lemmas labelled `ex:arith-finite-heegner`, `ex:arith-local-kummer`, `ex:arith-conjugate-duality`, `ex:arith-paired-functional`, `ex:limits-derivative-switch`, `ex:limits-inner-limit`, `ex:limits-outer-evaluation`, and `ex:limits-uniform-lower-bound`. Reconstruct the actual chain maps (including local boundary witnesses and cone homotopies), cup-product adjunction, determinant exact triangles, and equality of the **same class-functional coordinate up to an integral unit**. Test every localization used, including `(t)`, `(t+2)` and the completed 2-adic DVR, divisible localization vectors, torsion, zero/exceptional branches, sign conventions and fixed multipliers. The critical output is a **commutative diagram with verified maps and precise unit/scalar** or a minimal counterexample/missing hypothesis. Source-check Nekovář's relevant sections, not just a secondary review. Distinguish a homotopy-corrected cone map from strict Shapiro diagrams.

**Alternative B — six-contact height theorem, possible quantitative improvement.** Audit the theorem labelled `thm:height` and its local conductor argument. The existing proof bounds tame conductor at new primes by 2, yielding an `M_S(u)^2` level contribution and exponent 24 in the final height estimate. Determine the **actual inertia representation**, not just the branch index, and test whether exponent 1 is possible uniformly. If it is, prove all hypotheses and recalculate every downstream constant. If scalar inertia gives conductor 2, record a rigorous obstruction to this proposed improvement. Do not present an exponent-12 bound without proving the local representation assertion.

**Alternative C — prime-pattern source/application uniformity.** Audit the Gaussian linear replacement and the fixed-field polynomial count (`prop:v5-artin-patterns`), with particular attention to ranges where `T/sqrt(N)` tends to zero; published theorem versions, ray-field disjointness, nilsequence-to-polynomial transfer, boundary/majorant normalization and quantifier order. Prove the exact consumed asymptotic or exhibit a clear source-contract deficiency.

Only select a different target when the matrix shows it adds more coverage. Do not spend the round re-optimizing polynomial variable counts unless a independently justified semantic error or valuable verification deficiency is found.

## 4. Required mathematical method

For the selected target, build an application contract with these **nine checks**: (1) source hypotheses, (2) actual constructed objects, (3) domain/index coverage, (4) transitions/comparison maps, (5) identity of the downstream consumed object, (6) rings/lattices/normalizations, (7) local conditions, (8) exceptions and degeneracies, (9) affected downstream claims.

Use the precise source versions, theorem numbers, equations, and corrected editions. Trace the complete logic **source → construction → application → consumer**. Try to falsify it with a minimal countermodel or independently derived calculation. When code helps, make a small **independent checker**, not merely a wrapper around the author's checker. Show source/certificate hashes, exact arithmetic and negative controls.

Classify findings separately as: `VERIFIED`, `CONDITIONAL`, `OPEN / NOT YET CHECKED`, `INCOMPLETE JUSTIFICATION`, or `COUNTEREXAMPLE / INVALID`, with explicit evidence. An unreviewed step is not automatically false. A successful unit test is not a proof of an infinite or arithmetic assertion. A manuscript improvement must preserve the claimed object and every required implication, including soundness and completeness where relevant.

## 5. Focused checks and source protections

Run only appropriate checks after inspecting dependencies and cost. Current documented commands include:

```bash
python -B scripts/check_audit_history.py --self-test
python -B docs/manuscript-revisions/version13/validate-applications.py --repo . --self-test
python -B scripts/check_quartic394_portable.py
```

The last replays the 27-stage frozen quartic package and is useful only if working on construction/certificates; it does **not** verify the restricted converse. Re-resolve commands against the live version. The partial Lean snapshot has 48 helper modules; its main target contains `sorry`. Do not claim a complete formal proof from helper compilation or rewrite frozen releases to force a PASS.

Follow the repository's protocol v1.2 for evidence, non-author review, source contracts, release rules and negative controls. Never edit an old approval/hash to silence a failing check. Never invent a reviewer sign-off.

## 6. Sidecar output contract

Create these files under `../audit-output/2026-11-08/` (or a dated successor if the source has changed):

- `SNAPSHOT.md`: upstream SHA, version, manuscript SHA-256, environment, source paths and checks actually run.
- `COVERAGE_MATRIX.md`: at least the three candidates above, prior coverage, actual gaps/duplicate risk, and defended selection.
- `TARGET_CONTRACT.md`: exact proposition and its nine application obligations, with hyperlinks, theorem labels and line references.
- `DERIVATION.md`: complete independent argument or counterexample, including mathematical bounds, maps, signs, unit/denominator conditions, exceptions and downstream effects.
- `checks/` and `REPRODUCE.md`: small independent exact tests with negative controls, if meaningful; record that a test is insufficient where it is.
- `FINDINGS.md`: claim-level status, evidence strength, unresolved obligations and disposition relative to earlier audits.
- `PATCH.md` or `proposed.patch` **only if warranted**: minimal self-contained repair or clarified lemma, without changing the frozen historical manuscript. Explain all affected consumers.
- `HANDOVER.md`: short conclusion, best contribution, exact outstanding proof obligation, commands and file pointers.

If a material error is found, identify the **first invalid inference** and the weakest repair that fixes it. If all checks pass, deliver an independently documented verified interface and explain exactly what the review adds. If no worthwhile improvement is justified, report that outcome rather than inventing one.

## 7. Boundaries and completion

This is a research-review and local patch-preparation mandate, **not** permission to push commits, open issues/PRs, publish a revision, contact authors, overwrite the Chey fork, or change a release. Do not mutate the current approved application contracts. No claim of independent peer review, full arithmetic proof or Hilbert's tenth problem resolution is authorized.

Stop after the selected vertical slice has a reproducible report and actionable handover. The accepted outcome can be a proved local lemma, exact source-contract correction, refutation of a proposed optimization, minimal counterexample, or a useful independently reproduced assurance result.

**Completion condition:** a reader unfamiliar with this conversation can reproduce the exact source snapshot, identify one genuine improvement or covered gap, inspect its mathematical justification, understand its limits, and locate every affected downstream assertion.
